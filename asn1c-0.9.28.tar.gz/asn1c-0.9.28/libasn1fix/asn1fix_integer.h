#ifndef	ASN1FIX_INTEGER_H
#define	ASN1FIX_INTEGER_H

int asn1f_fix_integer(arg_t *);		/* Type1 ::= INTEGER { a(1), b(2) } */

#endif	/* ASN1FIX_INTEGER_H */
